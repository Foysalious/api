<?php

namespace Dingo\Blueprint\Annotation\Method;

/**
 * @Annotation
 */
class Get extends Method
{
}
