<?php

namespace Dingo\Blueprint\Annotation\Method;

/**
 * @Annotation
 */
class Patch extends Method
{
}
