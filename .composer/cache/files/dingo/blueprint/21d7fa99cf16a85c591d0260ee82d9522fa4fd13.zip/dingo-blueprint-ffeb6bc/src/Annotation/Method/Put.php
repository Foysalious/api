<?php

namespace Dingo\Blueprint\Annotation\Method;

/**
 * @Annotation
 */
class Put extends Method
{
}
