<?php

namespace Dingo\Blueprint\Annotation;

/**
 * @Annotation
 */
class Versions
{
    /**
     * @var array
     */
    public $value;
}
