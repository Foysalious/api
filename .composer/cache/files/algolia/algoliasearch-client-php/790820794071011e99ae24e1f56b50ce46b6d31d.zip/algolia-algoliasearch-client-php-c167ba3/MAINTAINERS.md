## `algolia/algoliasearch-client-php` maintainers

| Name            | Email                       |
|-----------------|-----------------------------|
| Julien Bourdeau | julien.bourdeau@algolia.com |
| Raymond Rutjes  | raymond.rutjes@algolia.com  |
