# CHANGELOG

## 1.7.1 (release 2017-01-31)
- Make compatible with Laravel 5.4

## 1.1.0 (release 2016-05-03)

- Add option to dynamically set `autoIndex` and/or `autoDelete` by methods in model.

## 1.0.5 (release 2015-10-27)

- Fix slaves + env

## 1.0.3 (release 2015-07-07)

- Improve Documentation
- Add constistency for trait attributes
- Add browse and browseFrom method

## 1.0.2 (release 2015-06-30)

- Update vinkla/algolia

## 1.0.1 (released 2015-06-18)

- Fix issue in __callStatic of the trait
- Fix issue with static call inside model with static or self keyword

## 1.0.0 (released 2015-06-12)

- Initial stable release
