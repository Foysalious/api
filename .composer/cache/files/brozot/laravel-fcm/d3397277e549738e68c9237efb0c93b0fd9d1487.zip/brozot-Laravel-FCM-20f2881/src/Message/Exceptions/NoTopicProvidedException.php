<?php

namespace LaravelFCM\Message\Exceptions;

use Exception;

/**
 * Class NoTopicProvidedException.
 */
class NoTopicProvidedException extends Exception
{
}
