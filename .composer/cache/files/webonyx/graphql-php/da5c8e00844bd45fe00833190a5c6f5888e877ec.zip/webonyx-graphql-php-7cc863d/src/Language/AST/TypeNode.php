<?php
namespace GraphQL\Language\AST;


interface TypeNode
{
/**
 export type TypeNode = NamedTypeNode
                    | ListTypeNode
                    | NonNullTypeNode
 */
}

