<?php
namespace GraphQL\Language\AST;

interface HasSelectionSet
{
    /**
     * export type DefinitionNode = OperationDefinitionNode
     *                        | FragmentDefinitionNode
     */
}
