<?php
namespace GraphQL;


/**
 * Schema Definition
 *
 * @deprecated moved to GraphQL\Type\Schema
 */
class Schema extends \GraphQL\Type\Schema
{
}
