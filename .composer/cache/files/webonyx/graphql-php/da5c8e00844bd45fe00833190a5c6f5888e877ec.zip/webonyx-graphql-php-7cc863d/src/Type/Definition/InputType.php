<?php
namespace GraphQL\Type\Definition;

/*
export type GraphQLInputType =
  GraphQLScalarType |
  GraphQLEnumType |
  GraphQLInputObjectType |
  GraphQLList |
  GraphQLNonNull;
 */
interface InputType
{
}
