
# Backers

WebP Convert is an MIT-licensed open source project. It is free and always will be.

How is it financed then? Well, it isn't exactly. However, some people choose to support the development by buying the developer a cup of coffee, and some go even further, by becoming backers. Backers are nice folks making recurring monthly donations, and by doing this, they give me an excuse to put more work into the library than I really should.

To become a backer yourself, visit [my page at patreon](https://www.patreon.com/rosell)


## Active backers via Patron

| Name                   | Since date     |
| ---------------------- | -------------- |
| Max Kreminsky          | 2019-08-02     |
| [Mathieu Gollain-Dupont](https://www.linkedin.com/in/mathieu-gollain-dupont-9938a4a/) | 2020-08-26     |
| Nodeflame              | 2019-10-31     |
| Ruben Solvang          | 2020-01-08     |


Hi-scores:

| Name                     | Life time contribution   |
| ------------------------ | ------------------------ |
| Tammy Valgardson         | $90                      |        
| Max Kreminsky            | $65                      |        
| Ruben Solvang            | $14                      |        
| Dmitry Verzjikovsky      | $5                       |        

## Former backers - I'm still grateful :)
- Dmitry Verzjikovsky
- Tammy Valgardson
